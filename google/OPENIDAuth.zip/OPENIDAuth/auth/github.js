var passport = require('passport')
  , GitHubStrategy = require('passport-github').Strategy;
var User = require('../models/User');

passport.use(new GitHubStrategy({
    clientID: "d4b6cca35c9b811eee19",
    clientSecret: "ebeceedddf3dd0305532d56687f067d6a7bf0441",
    callbackURL: "http://127.0.0.1:3000/auth/github/callback"
  },
  function(accessToken, refreshToken, profile, done) {
    User.findOrCreate({userid: profile.id}, {name: profile.displayName,userid: profile.id}, function (err, user) {
         console.log(""+user);
     
      return done(err, user);
    });
  }
));

module.exports = passport;
